    <?php
        
        // $servername = "rdbms.strato.de";
        // $username = "dbu1687307";
        // $password = "fdekingmaSEITO21A";
        // $dbname = "dbs4316475";
        
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "testdatabase";
        
    ?>